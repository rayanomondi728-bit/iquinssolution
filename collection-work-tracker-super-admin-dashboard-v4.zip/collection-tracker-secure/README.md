# Collection Work Tracker — secure starter

## Roles and rules
- One Super Admin, bootstrapped from `.env` only when the database has no admin.
- No public sign-up. Admin creates agent/auditor accounts.
- Admin alone creates and edits customer accounts and assigns agents.
- Agents see only assigned customers and can submit payments; submissions are pending until admin approval.
- Admin approves/rejects payments. Payment records are append-only in this starter.
- Auditor can view customers and payments, but cannot write.
- Role checks are enforced by the Express backend, not only by hiding interface buttons.
- Passwords are hashed with bcrypt. Sessions are stored server-side in SQLite. Login attempts are rate-limited. Helmet sets security headers.

## Requirements
Install Node.js 20+ from https://nodejs.org/.

## Windows setup
1. Extract this ZIP.
2. Open Command Prompt in the `collection-tracker-secure` folder.
3. Run `copy .env.example .env`.
4. Open `.env` in Notepad. Set your own `ADMIN_EMAIL`, a unique `ADMIN_PASSWORD` (12+ characters), and a random `SESSION_SECRET` (32+ characters). Keep `.env private.
5. Run `npm install`.
6. Run `npm start`.
7. Open http://localhost:3000 and sign in with the admin email/password.

## Use
- Admin: Users → create employee account; Customers → add customer and assign agent.
- Agent: sign in using assigned email/password, see assigned customers, submit collection payment.
- Admin: Payments → approve/reject pending submissions. Approval reduces customer balance.
- Admin: Audit log → inspect recorded logins and changes.

## Phone and computer
The interface is responsive. This local version runs on the computer where Node.js is started. To use from phone and computer over the internet, deploy to a trusted host with HTTPS and persistent database storage. Do not expose the development server directly to the public internet.

## Before using real customer information
This is a learning/demo starter, not a fully audited production finance platform. Before public deployment: enable HTTPS, set `NODE_ENV=production` and `COOKIE_SECURE=true`, use a managed secret store, add CSRF protection and stricter origin checks, configure encrypted backups and restore testing, monitor access, and obtain an independent security review. Follow your organization's privacy rules and applicable Kenyan data-protection requirements. Do not store customer IDs or sensitive personal data that the system does not need.

## Notes
- Existing admin credentials are not overwritten on later starts. If you forget the admin password, use a secure admin password recovery procedure rather than deleting the database.
- This starter has no email-based password reset, MFA, CSRF tokens, cloud hosting configuration, or Excel export yet.
- Back up the `data/` folder before updates.
